<!DOCTYPE html>
<html>
<head>
    <title>New User Registered</title>
</head>
<body>
    <h1>New User Registered</h1>
    <p>A new user has registered on your website:</p>
    <p>Full Name: {{$fullName}} </p>
    <p>Please take appropriate action.</p>
</body>
</html>
