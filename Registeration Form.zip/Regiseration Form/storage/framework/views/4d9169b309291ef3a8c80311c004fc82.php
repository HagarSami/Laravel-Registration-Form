<footer>
  <div class="container">
  <p>&copy; <?php echo e(__('messages.my registration form webpage')); ?> </p>
 <p>&copy; <?php echo e(__('messages.copy write')); ?></p>
  </div>
</footer>

<!-- Include CSS stylesheet -->
<head>
<style>
    footer {
	background-color: #f2f2f2;
    filter: brightness(80%);
	padding: 35px;
	text-align: center;
	position: absolute;
	bottom: 2;
	width: 100%;
}

footer p {
	font-size: 11px;
	color: black;
}
</style>
</head><?php /**PATH C:\xampp\htdocs\example-app2\resources\views/footer.blade.php ENDPATH**/ ?>