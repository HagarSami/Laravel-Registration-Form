<!DOCTYPE html>
<html>
<head>
    <title>New User Registered</title>
</head>
<body>
    <h1>New User Registered</h1>
    <p>A new user has registered on your website:</p>
    <p>Full Name: <?php echo e($fullName); ?> </p>
    <p>Please take appropriate action.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\example-app2\resources\views/emails/new_user_registered.blade.php ENDPATH**/ ?>