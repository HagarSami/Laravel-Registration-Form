<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
$(document).ready(function() {
  $("#myForm").submit(function(e) {
    e.preventDefault();
    var form = $(this);
    var formData = new FormData(form[0]);
    $.ajax({
      url: "<?php echo e(route('store')); ?>",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function(response) {
        if (response.status === 'success') {
          alert(response.message);
          form.trigger("reset");
        } else {
          alert(response.message);
        }
      },
      error: function(jqXHR, textStatus, errorMessage) {
        alert(errorMessage);
      }
    });
  });
});
</script>

</head>

<body>

   
   <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main>
<br>
            
<form id="myForm" method="post" action="<?php echo e(route('store')); ?>" enctype="multipart/form-data" class="my-form" onsubmit="validateForm()">
<?php echo csrf_field(); ?>
            
<div class="form-group">
    <label for="full_name"><?php echo e(Lang::get('messages.full_name_label')); ?></label>
    <input type="text" name="full_name" id="full_name" placeholder="<?php echo e(Lang::get('messages.full_name_placeholder')); ?>" required>
</div>

<div class="form-group">
    <label for="user_name"><?php echo e(Lang::get('messages.user_name_label')); ?></label>
    <input type="text" name="user_name" id="user_name" placeholder="<?php echo e(Lang::get('messages.user_name_placeholder')); ?>" required>
</div>

<div class="form-group">
    <label for="birthdate"><?php echo e(Lang::get('messages.birthdate_label')); ?></label>
    <input type="date" name="birthdate" id="birthdate" placeholder="<?php echo e(Lang::get('messages.birthdate_placeholder')); ?>" required>
    <button type="button" id="get-actors-button"><?php echo e(Lang::get('messages.get_actors_button_label')); ?></button>
</div>

<div id="container"> </div>


<div class="form-group">
    <label for="phone"><?php echo e(Lang::get('messages.phone_label')); ?></label>
    <input type="tel" name="phone" id="phone" placeholder="<?php echo e(Lang::get('messages.phone_placeholder')); ?>" required>
</div>

<div class="form-group">
    <label for="address"><?php echo e(Lang::get('messages.address_label')); ?></label>
    <input type="text" name="address" id="address" placeholder="<?php echo e(Lang::get('messages.address_placeholder')); ?>" required>
</div>

<div class="form-group">
    <label for="password"><?php echo e(Lang::get('messages.password_label')); ?></label>
    <input type="password" name="password" id="password" placeholder="<?php echo e(Lang::get('messages.password_placeholder')); ?>" required>
</div>

<div class="form-group">
    <label for="confirm_password"><?php echo e(Lang::get('messages.confirm_password_label')); ?></label>
    <input type="password" name="confirm_password" id="confirm_password" placeholder="<?php echo e(Lang::get('messages.confirm_password_placeholder')); ?>">
</div>

<div class="form-group">
    <label for="email"><?php echo e(Lang::get('messages.email_label')); ?></label>
    <input type="email" name="email" id="email" placeholder="<?php echo e(Lang::get('messages.email_placeholder')); ?>" required>
</div>

<div class="form-group">
    <label for="user_image"><?php echo e(Lang::get('messages.user_image_label')); ?></label>
    <input type="file" name="user_image" id="user_image" required>
</div>
  <button type="submit" class="btn-submit" id=submit value="Add" ><?php echo e(Lang::get('messages.sub')); ?></button>
</form>
<br>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<script>

function switchLanguage(lang) {
  let baseURL = window.location.origin;
  if (lang == "en") {
    window.location.href = baseURL + "/en"
  } else {
    window.location.href = baseURL + "/ar"  
  }
}

</script>

<script src="<?php echo e(asset('js/actor_request.js')); ?>"></script>

<script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\example-app\resources\views/index.blade.php ENDPATH**/ ?>