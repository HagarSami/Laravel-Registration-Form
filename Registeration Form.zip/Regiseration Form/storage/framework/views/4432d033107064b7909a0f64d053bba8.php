<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
   <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main>
<br>




<form id="myForm" method="post" action="<?php echo e(route('store')); ?>" enctype="multipart/form-data" class="my-form" onsubmit="validateForm()">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="full_name">Full Name</label>
    <input type="text" name="full_name" id="full_name" required >
  </div>

  <div class="form-group">
    <label for="user_name">User Name</label>
    <input type="text" name="user_name" id="user_name" required>
  </div>

  <div class="form-group">
    <label for="birthdate">Birthdate</label>
    <input type="date" name="birthdate" id="birthdate" required>
    <button type="button" id="get-actors-button">Get Actors</button>
  </div>
  <div id="container"> </div>
  <div class="form-group">
    <label for="phone">Phone</label>
    <input type="tel" name="phone" id="phone" required>
  </div>

  <div class="form-group">
    <label for="address">Address</label>
    <input type="text" name="address" id="address" required>
  </div>

  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>
  </div>

  <div class="form-group">
    <label for="confirm_password">Confirm Password</label>
    <input type="password" name="confirm_password" id="confirm_password">
  </div>

  <div class="form-group">
    <label for="email">Email</label>
    <input type="email" name="email" id="email" required>
  </div>
  <div class="form-group">
    <label for="user_image">User Image</label>
    <input type="file" name="user_image" id="user_image" required>
  </div>
  <button type="submit" class="btn-submit" id=submit value="Add" >Submit</button>

</form>
<br>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>

</html><?php /**PATH C:\Users\MBR\Downloads\Ass2\example-app\resources\views/index.blade.php ENDPATH**/ ?>